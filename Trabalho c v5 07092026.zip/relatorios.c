#include <stdio.h>
#include <sqlite3.h>
#include "relatorios.h"

//Função para gerars relatórios climaticos

void gerarRelatorioClima(sqlite3 *db){
    sqlite3_stmt *stmt;

    const char *sql =
        "SELECT t.nome, c.data, c.hora, "
        "c.temperatura, c.umidade "
        "FROM clima c "
        "INNER JOIN talhoes t "
        "ON c.codigo_talhao = t.codigo "
        "ORDER BY "
        "substr(c.data, 7, 4) || '-' || "
        "substr(c.data, 4, 2) || '-' || "
        "substr(c.data, 1, 2), "
        "c.hora;";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        printf("Erro ao gerar relatorio de clima, tente novamente.\n");
        return;
    }

    printf("\n====================================\n");
    printf("          RELATORIO DE CLIMA\n");
    printf("====================================\n");

    while (sqlite3_step(stmt) == SQLITE_ROW) {

        printf("\n-----------------------------\n");
        printf("Talhao: %s\n", sqlite3_column_text(stmt, 0));
        printf("Data: %s\n", sqlite3_column_text(stmt, 1));
        printf("Hora: %s\n", sqlite3_column_text(stmt, 2));
        printf("Temperatura: %.1f C\n", sqlite3_column_double(stmt, 3));
        printf("Umidade: %.1f%%\n", sqlite3_column_double(stmt, 4));
    }
    printf("-----------------------------\n");

    sqlite3_finalize(stmt);
}


//Geram relatórios que relacionam clima e pragas

void gerarRelatorioPragasClima(sqlite3 *db){
    sqlite3_stmt *stmt;

    const char *sql =
        "SELECT t.nome, "
        "p.nome, "
        "o.nivel_infestacao, "
        "o.area_afetada, "
        "o.data, "
        "c.temperatura, "
        "c.umidade, "
        "c.data "
        "FROM ocorrencias_pragas o "
        "INNER JOIN pragas p "
        "ON o.codigo_praga = p.codigo "
        "INNER JOIN talhoes t "
        "ON o.codigo_talhao = t.codigo "
        "LEFT JOIN clima c "
        "ON c.id = ("
        "SELECT MAX(c2.id) "
        "FROM clima c2 "
        "WHERE c2.codigo_talhao = o.codigo_talhao "
        "AND c2.data = o.data"
        ") "
        "ORDER BY "
        "substr(o.data, 7, 4) || '-' || "
        "substr(o.data, 4, 2) || '-' || "
        "substr(o.data, 1, 2);";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        printf("Erro ao gerar relatorio de pragas e clima.\n");
        return;
    }

    printf("\n====================================\n");
    printf("       RELATORIO DE PRAGAS E CLIMA\n");
    printf("====================================\n");

    while (sqlite3_step(stmt) == SQLITE_ROW) {

        printf("\n-----------------------------\n");
        printf("Talhao: %s\n", sqlite3_column_text(stmt, 0));
        printf("Praga: %s\n", sqlite3_column_text(stmt, 1));
        printf("Nivel de infestacao: %d\n", sqlite3_column_int(stmt, 2));
        printf("Area afetada: %.2f hectares\n", sqlite3_column_double(stmt, 3));
        printf("Data da ocorrencia: %s\n", sqlite3_column_text(stmt, 4));

        if (sqlite3_column_text(stmt, 5) != NULL) {

            printf("Temperatura: %.1f C\n",
                   sqlite3_column_double(stmt, 5));

            printf("Umidade: %.1f%%\n",
                   sqlite3_column_double(stmt, 6));

            printf("Data do clima: %s\n",
                   sqlite3_column_text(stmt, 7));
        } 
        
        else {
            printf("Nao existem dados climaticos para esta data.\n");
        }
    }

    printf("-----------------------------\n");

    sqlite3_finalize(stmt);
}


//Faz um resumo por período de tempo

void resumoPorPeriodo(sqlite3 *db){
    char dataInicio[20];
    char dataFim[20];

    sqlite3_stmt *stmt;

    const char *sql =
        "SELECT COUNT(*), "
        "AVG(temperatura), "
        "AVG(umidade), "
        "MAX(temperatura), "
        "MIN(temperatura) "
        "FROM clima "
        "WHERE "
        "substr(data, 7, 4) || '-' || "
        "substr(data, 4, 2) || '-' || "
        "substr(data, 1, 2) "
        ">= "
        "substr(?, 7, 4) || '-' || "
        "substr(?, 4, 2) || '-' || "
        "substr(?, 1, 2) "
        "AND "
        "substr(data, 7, 4) || '-' || "
        "substr(data, 4, 2) || '-' || "
        "substr(data, 1, 2) "
        "<= "
        "substr(?, 7, 4) || '-' || "
        "substr(?, 4, 2) || '-' || "
        "substr(?, 1, 2);";

    printf("\n====================================\n");
    printf("          RESUMO POR PERIODO\n");
    printf("====================================\n");

    printf("Digite a data inicial (DD/MM/AAAA): ");
    scanf("%19s", dataInicio);

    printf("Digite a data final (DD/MM/AAAA): ");
    scanf("%19s", dataFim);

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        printf("Erro ao consultar periodo.\n");
        return;
    }

    sqlite3_bind_text(stmt, 1, dataInicio, -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, dataInicio, -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, dataInicio, -1, SQLITE_TRANSIENT);

    sqlite3_bind_text(stmt, 4, dataFim, -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, dataFim, -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, dataFim, -1, SQLITE_TRANSIENT);

    if (sqlite3_step(stmt) == SQLITE_ROW) {

        int quantidade = sqlite3_column_int(stmt, 0);

        printf("\nQuantidade de registros: %d\n",
               quantidade);

        if (quantidade > 0) {
            printf("Temperatura media: %.1f C\n", sqlite3_column_double(stmt, 1));
            printf("Umidade media: %.1f%%\n", sqlite3_column_double(stmt, 2));
            printf("Maior temperatura: %.1f C\n", sqlite3_column_double(stmt, 3));
            printf("Menor temperatura: %.1f C\n", sqlite3_column_double(stmt, 4));
        }
        else {
            printf("Nenhum registro encontrado no periodo.\n");
        }
    }

    sqlite3_finalize(stmt);
}

//Exporta os talhoes cadastrados para um arquivo CSV
void exportarTalhoesCSV(sqlite3 *db)
{
    FILE *arquivo;
    sqlite3_stmt *stmt;

    arquivo = fopen("talhoes.csv", "w");

    if (arquivo == NULL) {
        printf("\nErro ao criar arquivo.\n");
        return;
    }

    fprintf(arquivo, "Codigo;Nome;Area;Plantacao;Localizacao\n");

    const char *sql =
        "SELECT codigo, nome, area, plantacao, localizacao "
        "FROM talhoes "
        "ORDER BY codigo;";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        printf("\nErro ao consultar talhoes.\n");
        fclose(arquivo);
        return;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {

        fprintf(arquivo, "%d;%s;%.2f;%s;%s\n",
            sqlite3_column_int(stmt, 0),
            sqlite3_column_text(stmt, 1),
            sqlite3_column_double(stmt, 2),
            sqlite3_column_text(stmt, 3),
            sqlite3_column_text(stmt, 4));
    }

    sqlite3_finalize(stmt);
    fclose(arquivo);

    printf("\nArquivo talhoes.csv criado com sucesso!\n");
}

//Le as informacoes do arquivo CSV
void lerTalhoesCSV()
{
    FILE *arquivo;
    char linha[300];

    arquivo = fopen("talhoes.csv", "r");

    if (arquivo == NULL) {
        printf("\nArquivo talhoes.csv nao encontrado.\n");
        printf("Exporte os talhoes antes de realizar a leitura.\n");
        return;
    }

    printf("\n====================================\n");
    printf("       LEITURA DO ARQUIVO CSV\n");
    printf("====================================\n");

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        printf("%s", linha);
    }

    fclose(arquivo);
}